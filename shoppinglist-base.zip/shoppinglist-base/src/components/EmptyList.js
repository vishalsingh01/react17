import React from 'react';

const EmptyList = () => (
  <div>
    There are no items in your list.
  </div>
);

export default EmptyList;