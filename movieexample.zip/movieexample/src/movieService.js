// in order to get your own register an account with https://www.themoviedb.org/

const API_KEY = "e051a06c9b68c966d821e8186ff5db13";
const API_URL = "https://api.themoviedb.org/3";
const QUERY = `/trending/movie/week`;
const API_KEY_QUERY = `?api_key=${API_KEY}`;

const QUERY_STRING = `${API_URL}${QUERY}${API_KEY_QUERY}`;

export const getMovies = async () => {
  // Make a request to the movie database
  const res = await fetch(QUERY_STRING);
  const { results } = await res.json();

  const movies = results.map(({ id, release_date, title, poster_path }) => ({
    id,
    title,
    releaseDate: release_date,
    poster: `https://image.tmdb.org/t/p/w300${poster_path}`
  }));

  return movies;
};
