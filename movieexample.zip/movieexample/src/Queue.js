import React, { Fragment } from "react";
import PropTypes from "prop-types";
import { unstable_trace as trace } from "scheduler/tracing";
import "./Queue.css";

import MovieCard from "./MovieCard";
import MeasureRender from './MeasureRender.js';

const Queue = ({ queue, clearQueue }) => (
  <MeasureRender name="Queue">
  <Fragment>
    <div className="queue__header">
        <h1 id="queue">Queue</h1>
      <button className="button button__clear_queue" onClick={() => {
                trace("Clear Movies queue", performance.now(), () => {
                  clearQueue()
                })
                }
              }>clear queue</button>
    </div>

    <ul className="movie__list">
      {queue && queue.map((movie) => (
        <li key={movie.id}>
          <MovieCard  {...movie} />
        </li>
      ))}
    </ul>
  </Fragment>
  </MeasureRender>
);

Queue.propTypes = {
  queue: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string,
      movieId: PropTypes.number
    })
  ),
  clearQueue: PropTypes.func
  
};

Queue.defaultProps = {
  queue: []
};

export default Queue;
