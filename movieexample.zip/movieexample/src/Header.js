import React from "react";
import MeasureRender from './MeasureRender.js';


const Header = () => (
  <MeasureRender name="Header">
  <div>
    <h1 id="top">React Movies <a href="#queue">Queue</a></h1>
  </div>
  </MeasureRender>
);

export default Header;