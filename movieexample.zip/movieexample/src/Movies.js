import React, { Fragment,  Profiler} from "react";
import { unstable_trace as trace } from "scheduler/tracing";
import PropTypes from "prop-types";

import MovieCard from "./MovieCard";
import "./Movies.css";

// The Profiler requires an onRender function as a prop. React calls this 
// function any time a component within the profiled tree “commits” an update. 
// It receives parameters describing what was rendered and how long it took.
const callback = (id, phase, actualTime, baseTime, startTime, commitTime) => {
    console.log(`${id}'s ${phase} phase:`);
    console.log(`Actual time: ${actualTime}`);
    console.log(`Base time: ${baseTime}`);
    console.log(`Start time: ${startTime}`);
    console.log(`Commit time: ${commitTime}`);
}

const Movies = ({ movies, addToQueue }) => (
  <Fragment>
   <Profiler id="Movies" onRender={callback}> 
    <h2 hidden>Available Movies</h2>
    <ul className="movie__list">
      {movies && movies.map(movie => (
        <li key={movie.id}>
          <MovieCard 
            {...movie} 
            actionContent={(
              <button 
               className="button" 
               onClick={() => {
                trace("Add To Movies Queue", performance.now(), () => {
                  addToQueue(movie.id)
                })
                }
              }
              >+</button>
            )}
          />
        </li>
      ))}
    </ul>
  </Profiler> 
  </Fragment>
);

Movies.propTypes = {
  movies: PropTypes.arrayOf(
    PropTypes.shape({
      title: PropTypes.string,
      poster: PropTypes.string,
      releaseDate: PropTypes.string
    })
  )
};

Movies.defaultProps = {
  movies: []
};

export default Movies;
