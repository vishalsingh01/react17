Pre-rendering and Data Fetching

Next.js’ pre-rendering feature.
The two forms of pre-rendering: Static Generation and Server-side Rendering.
    Static Generation with data, and without data.
    getStaticProps  runs only on the server-side. It will never run on the client-side. 
    It won’t even be included in the JS bundle for the browser. Only Allowed in a Page

In development (npm run dev or yarn dev), getStaticProps runs on every request.
In production, getStaticProps runs at build time.

use getServerSideProps only if you need to pre-render a page whose data must be fetched at request time. 
Time to first byte (TTFB) will be slower than getStaticProps because the server must compute the result on every request, and the result cannot be cached by a CDN without extra configuration.

Dynamic Routing:
1. pages/post/[id]/index.js
==> matches /post/my-example (/post/:id)
2. pages/post/[id]/[comment].js
==> matches /post/my-example/a-comment (/post/:id/:comment)
These routes are automatically matched by the server. 