import Link from 'next/link'

function Index({ stars }) {
  return (
    <div>
      <p>Next.js has {stars} ⭐️</p>
      <Link href="/preact-stars">
        <a>How about preact?</a>
      </Link>

      <h1> Dynamic Routing</h1>
      <Link href="/post/[id]" as="/post/first">
          <a>First Post</a>
      </Link>
      <Link href="/post/[id]" as="/post/second">
          <a>Second Post</a>
      </Link>
    </div>
  )
}

export async function getStaticProps() {
  const res = await fetch('https://api.github.com/repos/vercel/next.js')
  const json = await res.json()

  return {
    props: {
      stars: json.stargazers_count,
    },
  }
}

export default Index