import React, { Component } from 'react';
import ReactCountdownClock from 'react-countdown-clock'
import { fetchUsers, sortListDescending } from './api/Users';

import worker from './worker.js';
import WebWorker from './WebWorker';


class App extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isLoading: true,
            users: [],
            isSorting: false,
        };
        this.sortAscending = this.sortAscending.bind(this);
        this.sortDescending = this.sortDescending.bind(this);
    }

    componentDidMount = () => {
        this.worker = new WebWorker(worker);
        fetchUsers().then(users => {
            this.setState({
                users,
                isLoading: false
            });
        })
    }

    sortAscending = () => {
        this.worker.postMessage(this.state.users);

        this.setState(prevState => ({
            ...prevState,
            isSorting: true
        }), () => {
            this.worker.addEventListener('message', (event) => {
                const sortedList = event.data;
                this.setState({
                    users: sortedList,
                    isSorting: false
                })
            });
        });

        return;
    }

    sortDescending = () => {
        this.setState(prevState => ({
            ...prevState,
            isSorting: true
        }), () => {
            const sortedList = sortListDescending(this.state.users)
            this.setState({
                users: sortedList,
                isSorting: false
            });
        });
    }



    render() {
         return (
           <>
                  <ReactCountdownClock seconds={100}
									   color="#e56"
									   alpha={0.9}
									   size={300}/>
                      <button
                                onClick={this.sortAscending}
                                type="button"
                                disabled={this.state.isLoading}>
                                Sort with WebWorker
                            </button>
                            <button
                                onClick={this.sortDescending}
                                type="button"
                                disabled={this.state.isLoading}>
                                Sort without WebWorker
                              </button>
                      
            </>
        );
    }
}

export default App;